T = 1000; % sample points
d = 3; % dimensions
mu_t = zeros(d,1); % scale points
df = 4; % degree of freedom
sigma_t = FC; % covariance matrix / correlation matrix
X = sample(T,mu_t,df,sigma_t);
% X = mu_t + scale _t .* mvtrnd(FC, df, n);