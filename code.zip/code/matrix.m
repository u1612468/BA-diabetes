tic
d = 3; % number of column & row
W = zeros(d,d);
C = rand(d);
W = C*C'; % matrix
for i=1:d
    for j=1:d
        a = sqrt(W(i,i));
        b = sqrt(W(j,j));
        FC(i,j) = W(i,j)/(a*b); % transfer w to FC, a correlation matrix
    end
end

clear i j eigenV C
[vec vals] = eig(FC);
% [V,D] = eig(A) returns diagonal matrix D of eigenvalues and 
% matrix V whose columns are the corresponding right eigenvectors, 
% so that A*V = V*D.

toc